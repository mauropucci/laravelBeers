<!DOCTYPE html>
<html>
<head>
    <title>API Error</title>
</head>
<body>
    <h1>An error occurred while fetching weather data:</h1>
    <p><?php echo e($error); ?></p>
</body>
</html><?php /**PATH D:\server\Laravel\rest-api-crud\resources\views/api_error.blade.php ENDPATH**/ ?>