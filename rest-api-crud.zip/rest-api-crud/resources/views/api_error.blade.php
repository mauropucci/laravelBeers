<!DOCTYPE html>
<html>
<head>
    <title>API Error</title>
</head>
<body>
    <h1>An error occurred while fetching weather data:</h1>
    <p>{{ $error }}</p>
</body>
</html>